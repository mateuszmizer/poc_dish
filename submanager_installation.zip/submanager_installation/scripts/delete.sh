#!/bin/bash
ctx logger info "delete kubeconfig"
rm -rf ${KUBECONFIG_PATH}
